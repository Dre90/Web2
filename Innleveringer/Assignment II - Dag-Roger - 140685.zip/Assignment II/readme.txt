Open setup.php in your favorit code editor
Edit line 3 and 4
    $user = 'root';
    $pass = '';

Then in your browser of choice go to setup.php

There is two user premade
Username: admin
Password: admin

Username: user
Password: user

Or you can make your own user.

In the "Articles to upload" folder there is two articles examples you can use.
