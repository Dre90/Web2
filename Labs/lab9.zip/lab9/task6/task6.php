<?php

    if(preg_match("/^[A-Z]/", "The text to test")) {
        echo 'yepp, its uppercase';
    }else{
        echo 'nope, its not upper case';
    }

 ?>
